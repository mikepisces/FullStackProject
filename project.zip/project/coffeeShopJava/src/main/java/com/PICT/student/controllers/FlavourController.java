package com.PICT.student.controllers;


import com.PICT.student.models.Flavour;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;

import com.PICT.student.repository.FlavourRepository;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping(path = "flavours")
public class FlavourController {

    @Autowired
    private FlavourRepository flavourRepository;

    @GetMapping("/get")
    public List<Flavour> getFlavour(){

        //List<Flavour> flavour = new ArrayList<Flavour>();
        //Flavour flavour1 = new Flavour(1,"Mocha kuka",10.0);
        //flavour.add(flavour1);
        //Flavour flavour2 = new Flavour(2,"Cappuchino",100.25);
        //flavour.add(flavour2);
        //return flavour;

        return flavourRepository.findAll();
    }
	
	@PostMapping("/add")
	public void createFlavour(@RequestBody Flavour flavour)  {
	
		flavourRepository.save(flavour);
		
	}
	
	@DeleteMapping(path = { "/{id}" })
	public Flavour deleteBook(@PathVariable("id") long id) {
		Flavour flavour = flavourRepository.getOne(id);
		flavourRepository.deleteById(id);
		return flavour;
	}
	
	@PutMapping("/update")
	public void updateBook(@RequestBody Flavour flavour) {
		flavourRepository.save(flavour);
	}
}
