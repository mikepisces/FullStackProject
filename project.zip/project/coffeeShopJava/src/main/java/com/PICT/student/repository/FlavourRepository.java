package com.PICT.student.repository;

public interface FlavourRepository extends JpaRepository<Flavour, Integer> {
}

