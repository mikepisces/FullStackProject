import { Component, OnInit,Input,EventEmitter, Output } from '@angular/core';
import { Ingredient } from 'src/app/model/Ingredient';
import { HttpClientService } from 'src/app/service/http-client.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewingredient',
  templateUrl: './viewingredient.component.html',
  styleUrls: ['./viewingredient.component.css']
})
export class ViewingredientComponent implements OnInit {

  @Input()
  ingredient: Ingredient;

  @Output()
  bookDeletedEvent = new EventEmitter();


  constructor(private httpClientService: HttpClientService, private router: Router
    ) { }

  ngOnInit() {
  }

  deleteFlavour() {
    this.httpClientService.deleteFlavour(this.ingredient.id).subscribe(
      (book) => {
        this.bookDeletedEvent.emit();
        this.router.navigate(['admin', 'ingredients']);
      }
    );
  }

  editFlavour() {
    this.router.navigate(['admin', 'ingredients'], { queryParams: { action: 'edit', id: this.ingredient.id } });
  }

}
