import { Component, OnInit } from '@angular/core';
import { Flavour } from 'src/app/model/Flavour';
import { HttpClientService } from 'src/app/service/http-client.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-flavours',
  templateUrl: './flavours.component.html',
  styleUrls: ['./flavours.component.css']
})
export class FlavoursComponent implements OnInit {

  flavours: Array<Flavour>;
  flavoursRecieved: Array<Flavour>;
  action: string;
  selectedFlavour: Flavour;

  constructor(private httpClientService: HttpClientService,
    private activedRoute: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
    this.refreshData();
   }

   refreshData()
   {
    this.httpClientService.getFlavours().subscribe(
      response => this.handleSuccessfulResponse(response)
    );
    this.activedRoute.queryParams.subscribe(
      (params) => {
        // get the url parameter named action. this can either be add or view.
        this.action = params['action'];
	// get the parameter id. this will be the id of the book whose details 
	// are to be displayed when action is view.
	const id = params['id'];
	// if id exists, convert it to integer and then retrive the book from
	// the books array
        if (id) {
          this.selectedFlavour = this.flavours.find(flavour => {
            return flavour.id === +id;
          });
        }
      }
    );
   }
 
   // we will be taking the flavour response returned from the database
  // and we will be adding the retrieved   
  handleSuccessfulResponse(response) {
    this.flavours = new Array<Flavour>();
    //get flavour returned by the api call
    this.flavours = response;
    for (const flavour of this.flavoursRecieved) {
    
      const flavourwithRetrievedImageField = new Flavour();
      flavourwithRetrievedImageField.id = flavour.id;
      flavourwithRetrievedImageField.name = flavour.name;

      flavourwithRetrievedImageField.price = flavour.price;

      this.flavours.push(flavourwithRetrievedImageField);
    }
  }

   addFlavour() {
    this.selectedFlavour = new Flavour();
    this.router.navigate(['admin', 'flavours'], { queryParams: { action: 'add' } });
  }

  viewFlavour(id: number) {
    this.router.navigate(['admin', 'flavours'], { queryParams: { id, action: 'view' } });
  }

}
