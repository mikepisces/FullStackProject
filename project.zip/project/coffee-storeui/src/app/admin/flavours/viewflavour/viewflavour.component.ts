import { Component, OnInit,Input,EventEmitter, Output } from '@angular/core';
import { Flavour } from 'src/app/model/Flavour';
import { HttpClientService } from 'src/app/service/http-client.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewbook',
  templateUrl: './viewflavour.component.html',
  styleUrls: ['./viewflavour.component.css']
})
export class ViewbookComponent implements OnInit {

  @Input()
  book: Flavour;

  @Output()
  bookDeletedEvent = new EventEmitter();


  constructor(private httpClientService: HttpClientService, private router: Router
    ) { }

  ngOnInit() {
  }

  deleteFlavour() {
    this.httpClientService.deleteFlavour(this.book.id).subscribe(
      (book) => {
        this.bookDeletedEvent.emit();
        this.router.navigate(['admin', 'flavours']);
      }
    );
  }

  editFlavour() {
    this.router.navigate(['admin', 'flavours'], { queryParams: { action: 'edit', id: this.book.id } });
  }

}
