import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClientService } from '../service/http-client.service';
import { Flavour } from '../model/Flavour';
import { Ingredient } from '../model/Ingredient';

@Component({
  selector: 'app-shopbook',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css']
})
export class ShopComponent implements OnInit {

  flavours: Array<Flavour>;
  flavoursRecieved: Array<Flavour>;
  ingredients: Array<Ingredient>;
  ingredientsRecieved: Array<Ingredient>;
  cart: any;

  constructor(private router: Router, private httpClientService: HttpClientService) { }


  ngOnInit() {
    this.httpClientService.getFlavours().subscribe(
      response => this.handleSuccessfulResponse(response),
    );

    this.httpClientService.getIngredients().subscribe(
      response2=> this.handleSuccessfulResponse(response2),
    );
    //from localstorage retrieve the cart item
    let data = localStorage.getItem('cart');
    //if this is not null convert it to JSON else initialize it as empty
    if (data !== null) {
      this.cart = JSON.parse(data);
    } else {
      this.cart = [];
    }
  }

  // we will be taking the flavours response returned from the database
  // and we will be adding the retrieved   
  handleSuccessfulResponse(response) {
    this.flavours = new Array<Flavour>();
    //get flavours returned by the api call
    this.flavoursRecieved = response;
    for (const flavour of this.flavoursRecieved) {
      this.flavours.push(flavour);
    }
  }

  handleSuccessfulResponse2(response2) {
    this.ingredients = new Array<Ingredient>();
    //get books returned by the api call
    this.ingredientsRecieved = response2;
    for (const ingredient of this.ingredientsRecieved) {
      this.ingredients.push(ingredient);
    }
  }

 
  addToCart(flavourId) {
    //retrieve item from books array using the item id
    let flavour = this.flavours.find(flavour => {
      return flavour.id === +flavourId;
    });
    let cartData = [];
    //retrieve cart data from localstorage
    let data = localStorage.getItem('cart');
    console.log(data);
    //prse it to json 
    if (data !== null) {
      cartData = JSON.parse(data);
    }
    console.log('hii');
    // add the selected item to cart data
    cartData.push(flavour);
    //updated the cartBooks
    this.updateCartData(cartData);
    //save the updated cart data in localstorage
    localStorage.setItem('cart', JSON.stringify(cartData));
    //make the isAdded field of the item added to cart as true
    flavour.isAdded = true;
  }

  updateCartData(cartData) {
    this.cart = cartData;
  }

  goToCart() {
    this.router.navigate(['/cart']);
  }

  emptyCart() {
    this.cart = [];
    localStorage.clear();
  }

}
