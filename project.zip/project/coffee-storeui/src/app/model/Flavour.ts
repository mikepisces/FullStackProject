export class Flavour {
    id: number;
    name: string;
    price: number;
    isAdded: boolean;
    }

   