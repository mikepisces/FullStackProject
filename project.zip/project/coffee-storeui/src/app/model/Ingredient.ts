export class Ingredient {
    id: number;
    name: string;
    price: number; 
    isAdded: boolean;
    }