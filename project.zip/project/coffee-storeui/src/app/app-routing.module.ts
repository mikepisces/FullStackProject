import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UsersComponent } from './admin/users/users.component';
import { FlavoursComponent } from './admin/flavours/flavours.component';
import { ShopComponent } from './shop/shop.component';
import {IngredientsComponent} from './admin/ingredients/ingredients.component';


const routes: Routes = [
  { path: 'admin/users', component: UsersComponent },
  { path: 'admin/flavours', component: FlavoursComponent },
  { path: 'admin/ingredients', component: IngredientsComponent},
  { path: 'shop', component: ShopComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
