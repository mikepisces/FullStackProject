import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { UsersComponent } from './admin/users/users.component';
import { HttpClientModule } from '@angular/common/http';
import { AdduserComponent } from './admin/users/adduser/adduser.component';
import { ViewuserComponent } from './admin/users/viewuser/viewuser.component';
import { FlavoursComponent } from './admin/flavours/flavours.component';
import { AddFlavourComponent } from './admin/flavours/addflavour/addflavour.component';
import { ViewbookComponent } from './admin/flavours/viewflavour/viewflavour.component';
import { ShopComponent } from './shop/shop.component';
import {IngredientsComponent} from './admin/ingredients/ingredients.component';

@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    UsersComponent,
    AdduserComponent,
    ViewuserComponent,
    FlavoursComponent,
    AddFlavourComponent,
    ViewbookComponent,
    ShopComponent,
    IngredientsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
